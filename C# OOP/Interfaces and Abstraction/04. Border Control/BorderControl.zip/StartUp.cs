﻿using BorderControl.Models;
using BorderControl.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> identifiables = new List<IIdentifiable>();

            string command;
            while ((command = Console.ReadLine()) != "End")
            {
                string[] commandArgs = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                IIdentifiable identifiable;
                if (commandArgs.Length == 3)
                {
                    string name = commandArgs[0];
                    int age = int.Parse(commandArgs[1]);
                    string id = commandArgs[2];

                    identifiable = new Citizen(name, age, id);
                }
                else
                {
                    string model = commandArgs[0];
                    string id = commandArgs[1];

                    identifiable = new Robot(model, id);
                }

                identifiables.Add(identifiable);
            }

            string fakeDigits = Console.ReadLine();

            foreach (var identifiable in identifiables.Where(iden => iden.ID.EndsWith(fakeDigits)))
            {
                Console.WriteLine(identifiable.ID);
            }
        }
    }
}
